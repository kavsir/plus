import json
import threading
from datetime import datetime
from collections import deque

import psycopg2
import paho.mqtt.client as mqtt
from flask import Flask, render_template, jsonify, request

# ================== CONFIG ==================
MQTT_BROKER = "broker.emqx.io" 
MQTT_PORT   = 1883

# Kết nối PostgreSQL
PG_CONN = psycopg2.connect(
    dbname="homework",
    user="postgres",
    password="123456",
    host="localhost",
    port=5432
)
PG_CONN.autocommit = True

# MQTT Topics
TOPIC_DATA    = "vax/data"
TOPIC_CMD     = "vax/control"

# ================== FLASK APP ==================
app = Flask(__name__)
# Lưu cache để hiển thị biểu đồ và bảng ngay khi load trang
recent_data = deque(maxlen=100)

# ================== DB HELPERS ==================
def insert_to_db(device_id, temp, stat_str):
    try:
        with PG_CONN.cursor() as cur:
            # 1. Đảm bảo có device trong DB (Tránh lỗi Foreign Key)
            cur.execute("""
                INSERT INTO devices (device_id, location_name) 
                VALUES (%s, 'Kho Chinh') 
                ON CONFLICT (device_id) DO NOTHING
            """, (device_id,))
            
            # 2. Chèn dữ liệu đo đạc
            status_int = 1 if stat_str == "ON" else 0
            cur.execute("""
                INSERT INTO telemetry (device_id, temperature, measured_at, status)
                VALUES (%s, %s, NOW(), %s)
            """, (device_id, temp, status_int))
            print(f"✅ Đã lưu DB: {device_id} | {temp}°C | {stat_str}")
    except Exception as e:
        print(f"❌ Lỗi Database: {e}")

# ================== MQTT CALLBACKS ==================
def on_connect(client, userdata, flags, rc, properties=None):
    if rc == 0:
        print("✅ Đã kết nối Broker EMQX!")
        client.subscribe(TOPIC_DATA)
    else:
        print(f"❌ Lỗi kết nối MQTT, mã: {rc}")

def on_message(client, userdata, msg):
    try:
        payload = msg.payload.decode()
        data = json.loads(payload)
        
        dev = data.get("dev", "ESP32_01")
        t = data.get("temp", 0)
        s = data.get("stat", "OFF") # Lấy 'stat' từ ESP32
        
        # Lưu vào Database
        insert_to_db(dev, t, s)
        
        # Cập nhật cache Web (Dùng key 'status' để khớp với code HTML Dashboard)
        recent_data.append({
            "dev": dev, 
            "temp": t, 
            "status": s, 
            "time": datetime.now().strftime("%H:%M:%S")
        })
    except Exception as e:
        print(f"❌ Lỗi xử lý tin nhắn: {e}")

# ================== ROUTES ==================
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/data")
def get_data():
    return jsonify(list(recent_data))

@app.route("/api/command", methods=["POST"])
def send_cmd():
    cmd_data = request.json
    cmd = cmd_data.get("cmd")
    if cmd:
        mqtt_c.publish(TOPIC_CMD, cmd)
        print(f"📤 Đã gửi lệnh: {cmd}")
        return jsonify({"status": "sent"})
    return jsonify({"status": "error"}), 400

# ================== CHẠY HỆ THỐNG ==================
mqtt_c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
mqtt_c.on_connect = on_connect
mqtt_c.on_message = on_message

if __name__ == "__main__":
    # Kết nối và chạy MQTT trong luồng riêng
    mqtt_c.connect(MQTT_BROKER, MQTT_PORT, 60)
    threading.Thread(target=mqtt_c.loop_forever, daemon=True).start()
    
    # Chạy Flask Server
    print("🌐 Dashboard: http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)